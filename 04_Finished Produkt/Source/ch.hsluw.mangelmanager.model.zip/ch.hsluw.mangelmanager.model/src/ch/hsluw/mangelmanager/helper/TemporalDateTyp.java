package ch.hsluw.mangelmanager.helper;

public enum TemporalDateTyp {
		DATE, //java.sql.Date
		TIME, //java.sql.Time
		TIMESTAMP //java.sql.Timestamp
}
